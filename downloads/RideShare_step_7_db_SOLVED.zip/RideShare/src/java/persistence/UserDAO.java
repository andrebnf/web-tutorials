/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistence;

import model.User;
import java.sql.*;   
/**
 *
 * @author andrebnf
 */
public class UserDAO {
  private Connection connection;  
  
  public UserDAO() throws DAOException{
    this.connection = ConnectionFactory.getConnection();
  }
  
  public void save(User u) throws SQLException {
    PreparedStatement statement;

    String SQL = "INSERT INTO user"
        + "(username, email, password) VALUES(' "
              + u.getUsername() + " ', ' "
              + u.getEmail() + " ', ' "
              + u.getPassword() + " ' )";

    statement = connection.prepareStatement(SQL);
    statement.executeUpdate(); // executes query
  }    
}
