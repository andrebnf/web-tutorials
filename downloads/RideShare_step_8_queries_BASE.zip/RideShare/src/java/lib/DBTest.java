package lib;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class DBTest {
  //conn stores connection info from DBMS (Database Management System)
  private Connection conn;
  //stmt is used to send commands to the DBMS
  private Statement stmt;
  
  public DBTest() {
    try {
      Class.forName("com.mysql.jdbc.Driver").newInstance();
      String connection="jdbc:mysql://localhost/ride";
      String user="root", password="";
      Connection conn = DriverManager.getConnection(connection, user, password);
      
      stmt = conn.createStatement();

      System.out.println("Cool Bananas!");

      conn.close();
    } catch (Exception e) {
      e.printStackTrace();
      System.out.println("Error: something went wrong...");
    }
  }
  
  public static void main(String args[]) {
    DBTest t = new DBTest();
  }
}   