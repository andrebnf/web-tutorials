/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Route;

/**
 *
 * @author andrebnf
 */
public class SearchRouteStatus extends HttpServlet {

  /**
   * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
   * methods.
   *
   * @param request servlet request
   * @param response servlet response
   * @throws ServletException if a servlet-specific error occurs
   * @throws IOException if an I/O error occurs
   */
  protected void processRequest(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    response.setContentType("text/html;charset=UTF-8");
    try (PrintWriter out = response.getWriter()) {
      /* TODO output your page here. You may use following sample code. */
      out.println("<!DOCTYPE html>");
      out.println("<html>");
      out.println("<head>");
      out.println("<title>Servlet SearchRouteStatus</title>");      
      out.println("</head>");
      out.println("<body>");
      out.println("<h1>Servlet SearchRouteStatus at " + request.getContextPath() + "</h1>");
      out.println("</body>");
      out.println("</html>");
    }
  }

  // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
  /**
   * Handles the HTTP <code>GET</code> method.
   *
   * @param request servlet request
   * @param response servlet response
   * @throws ServletException if a servlet-specific error occurs
   * @throws IOException if an I/O error occurs
   */
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    int n = Integer.parseInt(request.getParameter("route"));
    String district = request.getParameter("district");
    
    Route r = new Route();
    if (district.equals("Jd. São Paulo")) {
      switch(n){
        case 1:
          r.setRoute_name("Saragoza Residential to UFSCar");
          r.setRoute_status("50 minutes delay from 17:00 to 18:40");
          break;
        case 2:
          r.setRoute_name("Saragoza Residential to Iguatemi Shopping");
          r.setRoute_status("20 minutes delay from 17:00 to 18:30");
          break;
        default:
          r = null;
      }
    } else if(district.equals("Centro")) {
      switch(n){
        case 1:
          r.setRoute_name("Santo Antonio Bus Station to São Paulo Bus Terminal");
          r.setRoute_status("10 minutes delay from 16:00 to 18:00");
          break;
        case 2:
          r.setRoute_name("São Paulo Bus Station to Shopping");
          r.setRoute_status("10 minutes delay from 17:00 to 17:30");
          break;
        case 3:
          r.setRoute_name("Shopping to Water's Park");
          r.setRoute_status("1 hour delay from 16:00 to 17:30");
          break;
        case 4:
          r.setRoute_name("São Bento St to Real Bakery");
          r.setRoute_status("15 minutes delay from 16:00 to 17:00");
          break;
        default:
          r = null;
      }
    } else if(district.equals("Santa Rosália")) {
      switch(n){
        case 1:
          r.setRoute_name("Shopping to 14th PD");
          r.setRoute_status("1 hour delay from 16:00 to 17:00");
          break;
        case 2:
          r.setRoute_name("Shopping to Center");
          r.setRoute_status("30 minutes delay from 17:00 to 17:30");
          break;
        case 3:
          r.setRoute_name("14th PD to Soccer Arena");
          r.setRoute_status("15 minutes delay from 16:00 to 16:50");
          break;
        default:
          r = null;
      }
    } else {
      r = null;
    }
    
    request.setAttribute("route_bean", r);
      
    RequestDispatcher dispatcher = null;
    dispatcher = request.getRequestDispatcher("./checkroute.jsp");
    dispatcher.forward(request, response);
  }

  /**
   * Handles the HTTP <code>POST</code> method.
   *
   * @param request servlet request
   * @param response servlet response
   * @throws ServletException if a servlet-specific error occurs
   * @throws IOException if an I/O error occurs
   */
  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    processRequest(request, response);
  }

  /**
   * Returns a short description of the servlet.
   *
   * @return a String containing servlet description
   */
  @Override
  public String getServletInfo() {
    return "Short description";
  }// </editor-fold>

}
