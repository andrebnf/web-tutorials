/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Route;
import model.User;

/**
 *
 * @author andrebnf
 */
public class SearchRoute extends HttpServlet {

  /**
   * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
   * methods.
   *
   * @param request servlet request
   * @param response servlet response
   * @throws ServletException if a servlet-specific error occurs
   * @throws IOException if an I/O error occurs
   */
  protected void processRequest(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    response.setContentType("text/html;charset=UTF-8");
    try (PrintWriter out = response.getWriter()) {
      /* TODO output your page here. You may use following sample code. */
      out.println("<!DOCTYPE html>");
      out.println("<html>");
      out.println("<head>");
      out.println("<title>Servlet SearchRoute</title>");      
      out.println("</head>");
      out.println("<body>");
      out.println("<h1>Servlet SearchRoute at " + request.getContextPath() + "</h1>");
      out.println("</body>");
      out.println("</html>");
    }
  }

  // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
  /**
   * Handles the HTTP <code>GET</code> method.
   *
   * @param request servlet request
   * @param response servlet response
   * @throws ServletException if a servlet-specific error occurs
   * @throws IOException if an I/O error occurs
   */
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    String district = request.getParameter("district");
    String routes = "";
    
    response.setCharacterEncoding("UTF-8"); 
    
//    Route[] routes = null;
    if (district.equals("Jd. São Paulo")) {
      routes += "<option selected value=\"0\"></option>";
      routes += "<option value=\"1\">Saragoza Residential to UFSCar</option>";
      routes += "<option value=\"2\">Saragoza Residential to Iguatemi Shopping</option>";
    }
//      routes = new Route[2];
//      routes[0].setRoute_name("Saragoza Residential to UFSCar");
//      routes[0].setRoute_status("50 minutes delay from 17:00 to 18:40");
//      routes[1].setRoute_name("Saragoza Residential to Iguatemi Shopping");
//      routes[1].setRoute_status("20 minutes delay from 17:00 to 18:30");
    else if(district.equals("Centro")) {
      routes += "<option selected value=\"0\"></option>";
      routes += "<option value=\"1\">Santo Antonio Bus Station to São Paulo Bus Terminal</option>";
      routes += "<option value=\"2\">São Paulo Bus Station to Shopping</option>";
      routes += "<option value=\"3\">Shopping to Water's Park</option>";
      routes += "<option value=\"4\">São Bento St to Real Bakery</option>";

    }
//      routes = new Route[4];
//      routes[0].setRoute_name("Santo Antonio Bus Station to São Paulo Bus Terminal");
//      routes[0].setRoute_status("10 minutes delay from 16:00 to 18:00");
//      routes[1].setRoute_name("São Paulo Bus Station to Shopping");
//      routes[1].setRoute_status("10 minutes delay from 17:00 to 17:30");
//      routes[2].setRoute_name("Shopping to Water's Park");
//      routes[2].setRoute_status("1 hour delay from 16:00 to 17:30");
//      routes[3].setRoute_name("São Bento St to Real Bakery");
//      routes[3].setRoute_status("15 minutes delay from 16:00 to 17:00");
    else if(district.equals("Santa Rosália")) {
      routes += "<option selected value=\"0\"></option>";
      routes += "<option value=\"1\">Shopping to 14th PD</option>";
      routes += "<option value=\"2\">Shopping to Center</option>";
      routes += "<option value=\"3\">14th PD to Soccer Arena</option>";
    }
//      routes = new Route[3];
//      routes[0].setRoute_name("Shopping to 14th PD");
//      routes[0].setRoute_status("1 hour delay from 16:00 to 17:00");
//      routes[1].setRoute_name("Shopping to Center");
//      routes[1].setRoute_status("30 minutes delay from 17:00 to 17:30");
//      routes[2].setRoute_name("14th PD to Soccer Arena");
//      routes[2].setRoute_status("15 minutes delay from 16:00 to 16:50");
//    }
    
//    request.setAttribute("route_beans", routes);

//    RequestDispatcher dispatcher = null;
//    dispatcher = request.getRequestDispatcher("./routes.jsp");
//    dispatcher.forward(request, response);
    
    PrintWriter writer = response.getWriter();
    writer.print(routes);
    writer.close();
  }

  /**
   * Handles the HTTP <code>POST</code> method.
   *
   * @param request servlet request
   * @param response servlet response
   * @throws ServletException if a servlet-specific error occurs
   * @throws IOException if an I/O error occurs
   */
  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException {
    processRequest(request, response);
  }

  /**
   * Returns a short description of the servlet.
   *
   * @return a String containing servlet description
   */
  @Override
  public String getServletInfo() {
    return "Short description";
  }// </editor-fold>

}
