/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author andrebnf
 */
public class Route {
  private String name;
  private String route_status;

  public Route(){
    route_status = "no data";
  }   
  public String getRoute_name() {
    return name;
  }

  public void setRoute_name(String route_name) {
    this.name = route_name;
  }

  public String getRoute_status() {
    return route_status;
  }

  public void setRoute_status(String route_status) {
    this.route_status = route_status;
  }
  
  
}
